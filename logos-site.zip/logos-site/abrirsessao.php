<?php

session_start();

@$matricula = $_POST['matricula'];
@$senha = $_POST['senha'];

    include('conecta.php');

        $sql = mysqli_query($conecta, "SELECT * FROM aluno WHERE matricula = '$matricula' AND senha = '$senha'");

            if (mysqli_num_rows($sql) > 0) {
                $_SESSION['matricula'] = $matricula;
                $_SESSION['senha'] = $senha;

                header('location: boletim.php');

            
            } else {

                unset($_SESSION['matricula']);
                unset($_SESSION['senha']);
    
                echo "
                        <br>
                        <fieldset>
                            <b>Login ou senha inválidos.</b>
                            <br>
                            <a href='login.php'>Tentar novamente</a>
                        </fieldset>
                
                    ";
            }

?>