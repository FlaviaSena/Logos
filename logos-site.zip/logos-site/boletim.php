<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <!--LINK ASSOCIANDO O CÓDIGO À BIBLIOTECA BOOTSTRAP-->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">

    <title>Canal do Aluno</title>
</head>
<body>
    <!--MENU DE NAVEGAÇÃO DO SITE-->
    <nav class="navbar navbar-expand-lg fixed-top fw-bold align-items-center" style="background-color: #edf1f9;">

        <!--ÍCONE DA ESCOLA COM LINK DE REDIRECIONAMENTO PARA O INÍCIO-->
        <div class="container-fluid align-items-center">

            <a class="navbar-brand" href="#">
                <img src="imagens/logos-informatica-logo.png" alt="" width="140" height="50">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <!--OPÇÕES DO MENU-->
            <div class="collapse navbar-collapse" id="navbarSupportedContent">

                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" aria-current="page" href="index.html">Início</a>
                    </li>

                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="institucional.html" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Institucional</a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <li>
                                <a class="dropdown-item" href="institucional.html">História</a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="institucional.html">Conquistas</a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="institucional.html">Projetos</a>
                            </li>
                        </ul>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="cursos.html">Cursos</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="eventos.html">Eventos</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="duvidas.html">Dúvidas Frequentes</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="Fale.html">Fale Conosco</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="biblioteca.html">Biblioteca</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="matricula.html">Matrícula on-line</a>
                    </li>

                </ul>


                <button class="btn btn-primary " type="submit"><a class="text-white text-decoration-none" href="login.php">Canal do aluno</a></button>
                <button class="btn btn-danger " type="submit"><a class="text-white text-decoration-none" href="encSe.php">Sair</a></button>

            </div>
        </div>
    </nav>

    <br>
    <br>
    <br>
    <br>

    <hr>
    

    <?php
    include("conecta.php");
   $sql = mysqli_query($conecta, "SELECT * FROM aluno WHERE matricula = '$logado'");
while($linha = mysqli_fetch_array($sql)){

    $nome=$linha['nome'];
    $PHPtext = "Bem vindo $nome!!!!!";
    }
    ?>
    <script>
var JavaScriptAlert = <?php echo json_encode($PHPtext); ?>;
alert(JavaScriptAlert); // Your PHP alert!
    </script>
    <!--RODAPÉ DO SITE-->

    <style>
        .container-rodape {
            width: 100%;
        }
    </style>

    <footer class="container-rodape" style="background-color: #edf1f9;">

        <table class="table text-center table-light table-striped text-dark w-100">

            <tr>
                <td>
                    <img src="imagens/logos-informatica-logo.png" alt="" width="140" height="50">
                </td>
            </tr>

        </table>

        <table style="background-color: #edf1f9;">
            <tr>
                <td class="text-center p-4 w-25 align-items-center">

                    <p><strong>Unidade Méier</strong></p>
                    <p>Rua Dias da Cruz, 000, Méier, Rio de Janeiro/RJ <br> CEP 00000-000 <br> Tel: (00) 0000-0000 <br> E-mail: meier@logos.com.br </p>

                </td>
                <td class="text-center p-4 w-25 align-items-center">

                    <p><strong>Unidade Bonsucesso</strong></p>
                    <p>Rua Conde de Bonfim, 000, Tijuca, Rio de Janeiro/RJ <br> CEP 00000-000 <br> Tel: (00) 0000-0000 <br> E-mail: tijuca@logos.com.br </p>

                </td>
                <td class="text-center p-4 w-25 align-items-center">

                    <p><strong>Unidade Tijuca</strong></p>
                    <p>Rua Conde de Bonfim, 000, Tijuca, Rio de Janeiro/RJ <br> CEP 00000-000 <br> Tel: (00) 0000-0000 <br> E-mail: tijuca@logos.com.br </p>

                </td>
            </tr>
        </table>


        <table class="table text-center table-light table-striped text-dark w-100">
            <tr>
                <td>
                    <p class="fw-bold text-center mb-3">Desenvolvido por Flávia, Raphael e Rogerio no módulo de MS Project do Curso Técnico em Informática do SENAC Bonsucesso - 2022</p>
                </td>
            </tr>
        </table>


    </footer>
    <!-- JavaScript Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>

</body>
</html>